import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
//HttpInterceptor interface gives us a method which automatically execute for all out going Http request
//This gives you an opportunitu to carry out common functionality for all htt outgoing request
//For e.g- assing credentials through headers whle accessing ssecured rest endpoints
//this is mandatory to make entry of this class in app.module.ts file

//this is better way to send http request than writing call in each method which is in data.service.ts
export class JwtInterceptorService implements HttpInterceptor {

  constructor(private authenctication:AuthenticationService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log("In JWT Interceptor");
    let basicRequest=req.clone({
      setHeaders:{Authorization:'Bearer '+this.authenctication.getToken()} //sessiostorage is browzer storage object which contain token
    })
    return next.handle(basicRequest);
  }
}

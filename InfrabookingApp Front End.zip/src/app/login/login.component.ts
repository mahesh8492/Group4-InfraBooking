import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/model/Employee';
import { Role } from 'src/model/Role';
import { AuthenticationService } from '../authentication.service';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  emp:Employee=new Employee(0,"","",new Role);
  constructor(private empService:EmployeeService,private router:Router,public authentication:AuthenticationService) { }

  getData(){

    this.empService.checkUser(this.emp).subscribe(response=>{
        let token=response.jwt;//jwt is token
        console.log(token);
        //Following statement stores token in sessionstorage of browser
       // sessionStorage.setItem('token',token);//key- value pair name of key can be anything
          this.router.navigate(['room']); //here in programming we are using router.navigate method to navigate to other component
        });
  }

  ngOnInit() {
  }

}

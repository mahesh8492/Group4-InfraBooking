import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RoomComponent } from './room/room.component';
import { Route, RouterModule, Routes } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { GetroomComponent } from './getroom/getroom.component' 
import { FormsModule } from '@angular/forms';
import { JwtInterceptorService } from './Jwt-interceptor.service';

const routes: Routes=[
  {path:"login",component:LoginComponent},
  {path:"room",component:RoomComponent},
  {path:"home",redirectTo:""},
  {path:"",component:HomeComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RoomComponent,
    MenuComponent,
    GetroomComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule
  ],
  providers: [{provide:HTTP_INTERCEPTORS,useClass:JwtInterceptorService,multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }

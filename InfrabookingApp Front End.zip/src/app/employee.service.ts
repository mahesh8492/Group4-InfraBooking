import { Injectable } from '@angular/core';
import { Employee } from 'src/model/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  

  constructor() { }

  checkUser(emp:Employee):boolean{
    if(emp.email==='zensar' && emp.id===0 && emp.password===""){
      return true;
    }
    return false;
  }
}
 



import { Injectable } from '@angular/core';
import { flush } from '@angular/core/testing';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate {

  constructor(private router:Router) { }
  //calling method can be used
  canActivate(): boolean  {
   console.log("In CanActivate");
   //to do
   // check if user login is successfull if yes-> we should get true else false result
   // this result variable should be check in of block and accordingly navigation of application can be decided
   if(false){
     this.router.navigate(['login']);
     return false;
   }
   return true;
  }
}

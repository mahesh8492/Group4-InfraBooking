import { Component, Input, OnInit } from '@angular/core';
import { Room } from 'src/model/Room';
import { DataService } from '../data.service';

@Component({
  selector: 'app-getroom',
  templateUrl: './getroom.component.html',
  styleUrls: ['./getroom.component.css']
})
export class GetroomComponent implements OnInit {

  @Input()
  room:Room=new Room(0,"",0);
  constructor() { }

  ngOnInit() {
  }

}

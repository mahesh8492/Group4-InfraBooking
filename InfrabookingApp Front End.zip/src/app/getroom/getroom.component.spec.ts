import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetroomComponent } from './getroom.component';

describe('GetroomComponent', () => {
  let component: GetroomComponent;
  let fixture: ComponentFixture<GetroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

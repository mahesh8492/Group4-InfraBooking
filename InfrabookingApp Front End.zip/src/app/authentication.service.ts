import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }

  isLoggedin():boolean{
    let token=sessionStorage.getItem('token');
    return token!=null;
  }
//this method is responsible for returning value of token from sessionStorage
  getToken(){
    return sessionStorage.getItem('token');
  }
  //this method is responsible for storing token in sessionstorage
  setToken(token:string){
    sessionStorage.setItem('token',token);
  }


  //this method is reponsible for removing token from session storage
  logout(){
    sessionStorage.removeItem('token');
  }
}

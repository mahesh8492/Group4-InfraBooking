import { Component, OnInit } from '@angular/core';
import { Room } from 'src/model/Room';
import { DataService } from '../data.service';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {
  rooms : Room[]=[];
  room1:Room=new Room();
  getRoomBtnClick:boolean=false;
  outputMessage: string;
  constructor(private service:DataService) { }


  getData(idToBeFind:number){
    this.getRoomBtnClick=true;
    
     this.service.getRoomDataById(idToBeFind).subscribe(success => this.rooms=success,
      error => {
        if(error.status==500){
          this.outputMessage=error.status+' '+error.message
        }
        }
          );
  }

  deleteRoom(idToBeDeleted:number){
    this.getRoomBtnClick=false;
    console.log("deleted Room"+idToBeDeleted);
    
    let a=window.confirm("Do you really want to delete the Room?")
    if(a)
    {
      this.service.deleteRoomById(idToBeDeleted).subscribe(s=>{this.outputMessage="Message Deleted Successfully"});
      alert("Room"+idToBeDeleted+"is deleted Succesfully!");
    }

    




}
  ngOnInit() {
  }

}

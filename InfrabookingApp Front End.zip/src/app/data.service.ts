import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Room } from 'src/model/Room';

@Injectable({
  providedIn: 'root'
})
export class DataService {
 

  private rooms:Room[]=[];
  constructor(private http:HttpClient) {}

  getRoomsWithObservables(): Observable<Room[]> {
    return of(this.rooms);
  }

  getRoomDataById(idToBeFind:number){
    return this.http.get<Room[]>(environment.url+'/room/'+idToBeFind);
  }

  deleteRoomById(idToBeDeleted: number) {

    return this.http.delete(environment.url+'/room/'+idToBeDeleted);
  }
  
}

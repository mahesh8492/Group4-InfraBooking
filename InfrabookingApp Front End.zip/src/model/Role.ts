export class Role{
    constructor(public id:number=0,public authority:string=""){}
}
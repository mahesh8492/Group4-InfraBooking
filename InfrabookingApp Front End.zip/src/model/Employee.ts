import { Role } from "./Role";

export class Employee{
     constructor(public id:number=0,public email:string="",public password:"",public role:Role){}
}